var require = meteorInstall({"imports":{"api":{"directory.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/directory.js                                          //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

if (Meteor.isServer) {
  Meteor.publish('directory', function () {
    return Meteor.users.find({}, {
      username: true,
      _id: true
    });
  });
}
///////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/index.js                                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.link("./messages.js");
module.link("./directory.js");
///////////////////////////////////////////////////////////////////////

},"messages.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/messages.js                                           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
  getConvoId: () => getConvoId
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Messages = new Mongo.Collection('messages');
module.exportDefault(Messages);

function getConvoId(userId1, userId2) {
  const ids = [userId1, userId2];
  ids.sort();
  return ids.join('');
}

if (Meteor.isServer) {
  Meteor.publish('messages', function (userId) {
    if (!this.userId) return this.ready();
    return Messages.find({
      convoId: getConvoId(this.userId, userId)
    });
  });
}

Meteor.methods({
  'messages.send': function (_ref) {
    let [userId, text] = _ref;
    Messages.insert({
      convoId: getConvoId(this.userId, userId),
      author: Meteor.userId(),
      timestamp: Date.now(),
      text
    });
  }
});
///////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.link("../imports/api");
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
Meteor.startup(() => {
  try {
    Accounts.createUser({
      username: 'user1',
      password: 'aaa'
    });
    Accounts.createUser({
      username: 'user2',
      password: 'aaa'
    });
    Accounts.createUser({
      username: 'user2',
      password: 'aaa'
    });
  } catch (error) {
    if (error.reason !== 'Username already exists.') throw error;
  }
});
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGlyZWN0b3J5LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWVzc2FnZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwidXNlcnMiLCJmaW5kIiwidXNlcm5hbWUiLCJfaWQiLCJleHBvcnQiLCJnZXRDb252b0lkIiwiTW9uZ28iLCJNZXNzYWdlcyIsIkNvbGxlY3Rpb24iLCJleHBvcnREZWZhdWx0IiwidXNlcklkMSIsInVzZXJJZDIiLCJpZHMiLCJzb3J0Iiwiam9pbiIsInVzZXJJZCIsInJlYWR5IiwiY29udm9JZCIsIm1ldGhvZHMiLCJ0ZXh0IiwiaW5zZXJ0IiwiYXV0aG9yIiwidGltZXN0YW1wIiwiRGF0ZSIsIm5vdyIsIkFjY291bnRzIiwic3RhcnR1cCIsImNyZWF0ZVVzZXIiLCJwYXNzd29yZCIsImVycm9yIiwicmVhc29uIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBRVgsSUFBSUgsTUFBTSxDQUFDSSxRQUFYLEVBQXFCO0FBQ25CSixRQUFNLENBQUNLLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFlBQVk7QUFDdEMsV0FBT0wsTUFBTSxDQUFDTSxLQUFQLENBQWFDLElBQWIsQ0FBa0IsRUFBbEIsRUFBc0I7QUFBRUMsY0FBUSxFQUFFLElBQVo7QUFBa0JDLFNBQUcsRUFBRTtBQUF2QixLQUF0QixDQUFQO0FBQ0QsR0FGRDtBQUdELEM7Ozs7Ozs7Ozs7O0FDTkRSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVo7QUFBNkJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEU7Ozs7Ozs7Ozs7O0FDQTdCRCxNQUFNLENBQUNTLE1BQVAsQ0FBYztBQUFDQyxZQUFVLEVBQUMsTUFBSUE7QUFBaEIsQ0FBZDtBQUEyQyxJQUFJQyxLQUFKO0FBQVVYLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1UsT0FBSyxDQUFDVCxDQUFELEVBQUc7QUFBQ1MsU0FBSyxHQUFDVCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXJELE1BQU1VLFFBQVEsR0FBRyxJQUFJRCxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7QUFGQWIsTUFBTSxDQUFDYyxhQUFQLENBSWVGLFFBSmY7O0FBTU8sU0FBU0YsVUFBVCxDQUFvQkssT0FBcEIsRUFBNkJDLE9BQTdCLEVBQXNDO0FBQzNDLFFBQU1DLEdBQUcsR0FBRyxDQUFDRixPQUFELEVBQVVDLE9BQVYsQ0FBWjtBQUNBQyxLQUFHLENBQUNDLElBQUo7QUFDQSxTQUFPRCxHQUFHLENBQUNFLElBQUosQ0FBUyxFQUFULENBQVA7QUFDRDs7QUFFRCxJQUFJcEIsTUFBTSxDQUFDSSxRQUFYLEVBQXFCO0FBQ25CSixRQUFNLENBQUNLLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFVBQVNnQixNQUFULEVBQWlCO0FBQzFDLFFBQUksQ0FBQyxLQUFLQSxNQUFWLEVBQ0UsT0FBTyxLQUFLQyxLQUFMLEVBQVA7QUFFRixXQUFPVCxRQUFRLENBQUNOLElBQVQsQ0FBYztBQUNuQmdCLGFBQU8sRUFBRVosVUFBVSxDQUFDLEtBQUtVLE1BQU4sRUFBY0EsTUFBZDtBQURBLEtBQWQsQ0FBUDtBQUdELEdBUEQ7QUFRRDs7QUFFRHJCLE1BQU0sQ0FBQ3dCLE9BQVAsQ0FBZTtBQUNiLG1CQUFpQixnQkFBeUI7QUFBQSxRQUFoQixDQUFDSCxNQUFELEVBQVNJLElBQVQsQ0FBZ0I7QUFDeENaLFlBQVEsQ0FBQ2EsTUFBVCxDQUFnQjtBQUNkSCxhQUFPLEVBQUVaLFVBQVUsQ0FBQyxLQUFLVSxNQUFOLEVBQWNBLE1BQWQsQ0FETDtBQUVkTSxZQUFNLEVBQUUzQixNQUFNLENBQUNxQixNQUFQLEVBRk07QUFHZE8sZUFBUyxFQUFFQyxJQUFJLENBQUNDLEdBQUwsRUFIRztBQUlkTDtBQUpjLEtBQWhCO0FBTUQ7QUFSWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDdkJBeEIsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVo7QUFBOEIsSUFBSUYsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNEIsUUFBSjtBQUFhOUIsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQzZCLFVBQVEsQ0FBQzVCLENBQUQsRUFBRztBQUFDNEIsWUFBUSxHQUFDNUIsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUszR0gsTUFBTSxDQUFDZ0MsT0FBUCxDQUFlLE1BQU07QUFDbkIsTUFBSTtBQUNGRCxZQUFRLENBQUNFLFVBQVQsQ0FBb0I7QUFDbEJ6QixjQUFRLEVBQUUsT0FEUTtBQUVsQjBCLGNBQVEsRUFBRTtBQUZRLEtBQXBCO0FBSUFILFlBQVEsQ0FBQ0UsVUFBVCxDQUFvQjtBQUNsQnpCLGNBQVEsRUFBRSxPQURRO0FBRWxCMEIsY0FBUSxFQUFFO0FBRlEsS0FBcEI7QUFJQUgsWUFBUSxDQUFDRSxVQUFULENBQW9CO0FBQ2xCekIsY0FBUSxFQUFFLE9BRFE7QUFFbEIwQixjQUFRLEVBQUU7QUFGUSxLQUFwQjtBQUlELEdBYkQsQ0FhRSxPQUFPQyxLQUFQLEVBQWM7QUFDZCxRQUFJQSxLQUFLLENBQUNDLE1BQU4sS0FBaUIsMEJBQXJCLEVBQ0UsTUFBTUQsS0FBTjtBQUNIO0FBQ0YsQ0FsQkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgTWV0ZW9yLnB1Ymxpc2goJ2RpcmVjdG9yeScsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe30sIHsgdXNlcm5hbWU6IHRydWUsIF9pZDogdHJ1ZSB9KTtcbiAgfSk7XG59XG4iLCJpbXBvcnQgJy4vbWVzc2FnZXMuanMnXG5pbXBvcnQgJy4vZGlyZWN0b3J5LmpzJ1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5jb25zdCBNZXNzYWdlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtZXNzYWdlcycpO1xuXG5leHBvcnQgZGVmYXVsdCBNZXNzYWdlcztcblxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbnZvSWQodXNlcklkMSwgdXNlcklkMikge1xuICBjb25zdCBpZHMgPSBbdXNlcklkMSwgdXNlcklkMl1cbiAgaWRzLnNvcnQoKVxuICByZXR1cm4gaWRzLmpvaW4oJycpXG59XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgTWV0ZW9yLnB1Ymxpc2goJ21lc3NhZ2VzJywgZnVuY3Rpb24odXNlcklkKSB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZClcbiAgICAgIHJldHVybiB0aGlzLnJlYWR5KCk7XG5cbiAgICByZXR1cm4gTWVzc2FnZXMuZmluZCh7XG4gICAgICBjb252b0lkOiBnZXRDb252b0lkKHRoaXMudXNlcklkLCB1c2VySWQpXG4gICAgfSk7XG4gIH0pO1xufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdtZXNzYWdlcy5zZW5kJzogZnVuY3Rpb24oW3VzZXJJZCwgdGV4dF0pIHtcbiAgICBNZXNzYWdlcy5pbnNlcnQoe1xuICAgICAgY29udm9JZDogZ2V0Q29udm9JZCh0aGlzLnVzZXJJZCwgdXNlcklkKSxcbiAgICAgIGF1dGhvcjogTWV0ZW9yLnVzZXJJZCgpLFxuICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgdGV4dCxcbiAgICB9KVxuICB9XG59KVxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2FwaSdcblxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICB0cnkge1xuICAgIEFjY291bnRzLmNyZWF0ZVVzZXIoe1xuICAgICAgdXNlcm5hbWU6ICd1c2VyMScsXG4gICAgICBwYXNzd29yZDogJ2FhYSdcbiAgICB9KTtcbiAgICBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgIHVzZXJuYW1lOiAndXNlcjInLFxuICAgICAgcGFzc3dvcmQ6ICdhYWEnXG4gICAgfSk7XG4gICAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICB1c2VybmFtZTogJ3VzZXIyJyxcbiAgICAgIHBhc3N3b3JkOiAnYWFhJ1xuICAgIH0pO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGlmIChlcnJvci5yZWFzb24gIT09ICdVc2VybmFtZSBhbHJlYWR5IGV4aXN0cy4nKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgfVxufSk7XG4iXX0=
